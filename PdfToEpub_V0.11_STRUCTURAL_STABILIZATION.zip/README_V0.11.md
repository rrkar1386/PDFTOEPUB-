# PDF-to-EPUB V0.11 — Structural Reconstruction Stabilization

V0.11 is the next structural revision after V0.10. It preserves the successful V0.10 spatial model and adds document-level semantic validation rather than reverting to global X/Y sorting or one-block heuristics.

## What changes

- TABLE_LIKE is produced only from repeated multi-row two-anchor clusters. A single coincidental horizontal alignment cannot create a table cell.
- Short ordinary prose is no longer protected from paragraph joining merely because it looks "header-like".
- First-page title selection uses document context: author/source material following the candidate increases title confidence, while repository/category labels are penalized.
- Pre-title repository/institution metadata is separated from the primary reading stream when it is clearly metadata-like.
- Figure captions remain structural units; nearby image/courtesy/department source notes are explicitly related as `FIGURE_ATTRIBUTION`.
- Column detection remains conservative and does not use the V0.10 largest-start-X-gap heuristic.
- Full-width blocks remain reading-order barriers; region membership is retained until ordering is complete.
- Diagnostics report structural quality without hiding the actual block sequence.

## Pipeline

PDF spans → geometric cleanup → physical lines → furniture filtering → conservative spatial segmentation → region-local blocks → semantic structural validation → title/front-matter normalization → figure relations → document reading order → diagnostics

EPUB serialization remains deliberately deferred until this diagnostic reconstruction is reliable.

## Build

GitHub Actions uses Java 17 and Gradle 8.9. `versionCode=11`, `versionName=0.11`.

Application ID remains `com.pdf_to_epub.v06` for upgrade compatibility.

package com.pdf_to_epub.v06

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.InputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB\nV0.6 — Structural block classification"
            textSize = 28f
        }

        val select = Button(this).apply { text = "SELECT PDF" }
        val analyze = Button(this).apply { text = "ANALYZE + CLASSIFY" }

        output = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 0)
            setTextIsSelectable(true)
        }

        root.addView(title)
        root.addView(select)
        root.addView(analyze)
        root.addView(
            ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 0, 1f)
        )
        setContentView(root)

        select.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    )
                }, 100
            )
        }

        analyze.setOnClickListener {
            selectedUri?.let { analyzePdf(it) }
                ?: run { output.text = "Please select a PDF first." }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            try {
                data?.data?.let {
                    contentResolver.takePersistableUriPermission(
                        it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            } catch (_: Exception) {}
            output.text = "Selected PDF:\n${selectedUri ?: ""}"
        }
    }

    private fun analyzePdf(uri: Uri) {
        output.text = "Analyzing text, layout and structure…"
        Thread {
            try {
                val result = contentResolver.openInputStream(uri)?.use { analyzeFirstPage(it) }
                    ?: "Could not open PDF."
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread {
                    output.text = "Analysis error:\n${e.javaClass.simpleName}: ${e.message}"
                }
            }
        }.start()
    }

    private fun analyzeFirstPage(input: InputStream): String {
        PDDocument.load(input).use { doc ->
            if (doc.numberOfPages == 0) return "PDF has no pages."

            val stripper = LayoutStripper()
            stripper.startPage = 1
            stripper.endPage = 1
            stripper.sortByPosition = true
            stripper.getText(doc)

            val cleaned = deduplicateCharacters(stripper.items)
            val lines = buildLines(cleaned)
            val blocks = buildBlocks(lines)
            val classified = classifyBlocks(blocks)

            val sb = StringBuilder()
            sb.append("Pages: ${doc.numberOfPages}\n")
            sb.append("Analyzed page: 1\n")
            sb.append("Raw text items: ${stripper.items.size}\n")
            sb.append("After duplicate cleanup: ${cleaned.size}\n")
            sb.append("Detected lines: ${lines.size}\n")
            sb.append("Estimated blocks: ${blocks.size}\n\n")

            sb.append("RECONSTRUCTED TEXT\n")
            sb.append("-----------------\n")
            lines.forEach { sb.append(it.text.trim()).append('\n') }

            sb.append("\nCLASSIFIED LAYOUT BLOCKS\n")
            sb.append("------------------------\n")
            classified.forEachIndexed { i, b ->
                sb.append("BLOCK ${i + 1}\n")
                sb.append("TYPE: ${b.type}\n")
                sb.append("CONFIDENCE: ${b.confidence}\n")
                sb.append("x=${fmt(b.x)}  y=${fmt(b.y)}  w=${fmt(b.w)}  h=${fmt(b.h)}\n")
                sb.append("font≈${fmt(b.fontSize)}\n")
                sb.append("text: ${b.text.trim()}\n\n")
            }
            return sb.toString()
        }
    }

    data class Item(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float
    )

    data class Line(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    data class Block(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    data class ClassifiedBlock(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float,
        val type: String,
        val confidence: String
    )

    class LayoutStripper : PDFTextStripper() {
        val items = mutableListOf<Item>()

        override fun processTextPosition(text: TextPosition) {
            val s = text.unicode ?: return
            if (s.isNotEmpty() && s.any { !it.isWhitespace() }) {
                items.add(
                    Item(
                        text = s,
                        x = text.xDirAdj,
                        y = text.yDirAdj,
                        w = text.widthDirAdj,
                        h = text.heightDir,
                        fontSize = text.fontSizeInPt
                    )
                )
            }
        }
    }

    private fun deduplicateCharacters(items: List<Item>): List<Item> {
        if (items.isEmpty()) return emptyList()
        val result = mutableListOf<Item>()

        for (item in items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })) {
            val duplicate = result.any { old ->
                old.text == item.text &&
                    abs(old.x - item.x) <= 0.8f &&
                    abs(old.y - item.y) <= 0.8f &&
                    abs(old.fontSize - item.fontSize) <= 1.0f
            }
            if (!duplicate) result.add(item)
        }
        return result
    }

    private fun buildLines(items: List<Item>): List<Line> {
        if (items.isEmpty()) return emptyList()
        val sorted = items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })
        val lines = mutableListOf<MutableList<Item>>()

        for (item in sorted) {
            val target = lines.lastOrNull { line ->
                val avgY = line.map { it.y }.average().toFloat()
                val avgH = line.map { it.h }.average().toFloat()
                abs(item.y - avgY) <= max(2.5f, avgH * 0.55f)
            }
            if (target == null) lines.add(mutableListOf(item))
            else target.add(item)
        }

        return lines.map { chars ->
            val ordered = chars.sortedBy { it.x }
            var text = ""
            var previous: Item? = null

            for (c in ordered) {
                if (previous != null) {
                    val gap = c.x - (previous.x + previous.w)
                    val spaceThreshold =
                        max(1.2f, minOf(c.fontSize, previous.fontSize) * 0.22f)
                    if (gap > spaceThreshold) text += " "
                }
                text += c.text
                previous = c
            }

            val left = ordered.minOf { it.x }
            val right = ordered.maxOf { it.x + it.w }
            val top = ordered.minOf { it.y }
            val bottom = ordered.maxOf { it.y + it.h }
            val font = ordered.map { it.fontSize }.average().toFloat()

            Line(text, left, top, right - left, bottom - top, font)
        }.sortedBy { it.y }
    }

    private fun buildBlocks(lines: List<Line>): List<Block> {
        if (lines.isEmpty()) return emptyList()
        val blocks = mutableListOf<Block>()

        for (line in lines) {
            val previous = blocks.lastOrNull()

            if (previous != null) {
                val verticalGap = line.y - (previous.y + previous.h)
                val sameColumn =
                    abs(line.x - previous.x) <= max(18f, line.fontSize * 2.5f)
                val similarFont =
                    abs(line.fontSize - previous.fontSize) <=
                        max(2.5f, previous.fontSize * 0.25f)

                if (verticalGap <= max(10f, line.fontSize * 0.9f) &&
                    sameColumn && similarFont) {
                    previous.text += " " + line.text
                    val right = line.x + line.w
                    previous.w = max(previous.w, right - previous.x)
                    previous.h = max(previous.h, line.y + line.h - previous.y)
                    previous.fontSize =
                        (previous.fontSize + line.fontSize) / 2f
                    continue
                }
            }

            blocks.add(
                Block(line.text, line.x, line.y, line.w, line.h, line.fontSize)
            )
        }
        return blocks
    }

    private fun classifyBlocks(blocks: List<Block>): List<ClassifiedBlock> {
        if (blocks.isEmpty()) return emptyList()

        val medianFont = blocks.map { it.fontSize }.sorted().let { values ->
            if (values.size % 2 == 1) values[values.size / 2]
            else (values[values.size / 2 - 1] + values[values.size / 2]) / 2f
        }

        // First classify by strong semantic signals.  These rules deliberately
        // run before font-size rules so emails, URLs, notices and repository
        // material can never become headings just because they use a large font.
        val preliminary = blocks.map { b ->
            val t = b.text.trim()
            val lower = t.lowercase(Locale.US)
            val pair = when {
                isLicense(t) -> "LICENSE" to "HIGH"
                isCitation(t) -> "CITATION" to "HIGH"
                isUrl(t) -> "URL" to "HIGH"
                isNotice(t) -> "NOTICE" to "HIGH"
                isMetadata(t) -> "METADATA" to "HIGH"
                isAuthorLine(t) -> "AUTHOR" to "HIGH"
                looksLikeDate(t) -> "METADATA" to "HIGH"
                lower.contains("cancer concepts:") -> "SUBHEADING" to "HIGH"
                else -> null
            }
            pair ?: when {
                b.fontSize >= medianFont * 1.30f && t.length <= 180 ->
                    "HEADING" to "HIGH"
                b.fontSize >= medianFont * 1.12f && t.length <= 180 ->
                    "SUBHEADING" to "MEDIUM"
                else -> "BODY" to "LOW"
            }
        }

        // Promote the strongest plausible document title.  We explicitly exclude
        // metadata/front-matter/notice blocks so large repository text cannot win.
        val titleCandidate = blocks.indices
            .filter { i ->
                val type = preliminary[i].first
                type == "HEADING" || type == "SUBHEADING" || type == "BODY"
            }
            .filter { i ->
                val t = blocks[i].text.trim()
                t.length in 5..120 &&
                    !looksLikeDate(t) &&
                    !isNotice(t) &&
                    !t.contains("http://", true) &&
                    !t.contains("https://", true)
            }
            .maxWithOrNull(compareBy<Int> { blocks[it].fontSize }.thenBy { -blocks[it].y })

        return blocks.mapIndexed { index, b ->
            val t = b.text.trim()
            val result = if (index == titleCandidate) {
                "TITLE" to "HIGH"
            } else {
                preliminary[index]
            }

            ClassifiedBlock(
                t, b.x, b.y, b.w, b.h, b.fontSize,
                result.first, result.second
            )
        }
    }

    private fun isUrl(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("https://") || lower.contains("http://") ||
            lower.startsWith("www.")
    }

    private fun isCitation(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("repository citation") ||
            lower.contains("retrieved from") ||
            lower.contains("doi.org/") ||
            lower.contains("doi:")
    }

    private fun isLicense(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("creative commons license") ||
            lower.contains("licensed under a creative commons") ||
            lower.contains("creativecommons.org")
    }

    private fun isNotice(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.startsWith("let us know how access to this document") ||
            lower.startsWith("follow this and additional works at") ||
            lower.startsWith("for more information, please contact")
    }

    private fun isAuthorLine(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        if (lower.contains("@")) return false
        return lower.startsWith("by ") ||
            lower == "et al." ||
            Regex("\\b(et al\\.?|md|phd|ba|ma|rn|do)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) &&
            text.length <= 140
    }

    private fun isMetadata(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("university") ||
            lower.contains("medical school") ||
            lower.contains("department") ||
            lower.contains("center") ||
            lower.contains("eScholarship".lowercase(Locale.US)) ||
            lower.contains("@") ||
            lower.contains("commons") ||
            lower.contains("oncology") ||
            lower == "oncologist" ||
            lower.contains("repository")
    }

    private fun looksLikeDate(text: String): Boolean {
        return Regex("^(?:\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[-/]\\d{1,2}[-/]\\d{4})$")
            .matches(text.trim())
    }

    private fun fmt(v: Float): String =
        String.format(Locale.US, "%.1f", v)
}

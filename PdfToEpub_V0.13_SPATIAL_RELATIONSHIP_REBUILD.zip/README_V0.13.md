# PDF-to-EPUB V0.13 — Spatial Relationship Reconstruction

V0.13 is a controlled evolution of the last successful V0.12 APK build.

## Core objective
Improve PDF reflow by preserving spatial relationships long enough to distinguish
ordinary prose from repeated aligned structures.

## What is retained
- PDFBox glyph geometry extraction
- geometric duplicate suppression
- physical line construction
- running header/footer suppression
- persistent two-column detection
- region-local paragraph joining
- figure-caption/source/reference classification
- barrier-based column reading order
- existing Android/Gradle project and package/application ID

## What changed
V0.12 had a post-hoc embedded-pair repair that depended on a hard-coded list of
right-column medical terms. V0.13 removes that mechanism.

Text positions are now retained as `Fragment` objects inside each `Line`.
Repeated two-part rows are detected from their geometry:

    left anchor       right anchor
         |                 |
    row 1 -------------- row 1
    row 2 -------------- row 2
    row 3 -------------- row 3

At least three rows, stable anchors and reasonably consistent vertical spacing
are required before rows are marked TABLE_LIKE.

## Important safety rule
A single large gap, a single pair, or a word such as an em dash cannot by itself
create a table.

## Build
GitHub Actions builds the checked-in Android project and uploads:
`app/build/outputs/apk/debug/app-debug.apk`

No temporary project generation or external source ZIP is used.

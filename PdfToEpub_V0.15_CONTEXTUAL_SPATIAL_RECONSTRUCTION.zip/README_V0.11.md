# PDF-to-EPUB V0.11 — Structural Reconstruction Stabilization

V0.11 is a corrective architectural revision based on the V0.10 test output. It does **not** repeat the V0.10 table-detection or page-segmentation heuristics.

## Problems addressed

### 1. False `[TABLE-LIKE]` labels
V0.10 treated a block as table-like when one other block happened to share a similar Y coordinate. That produced widespread false positives (121 TABLE_LIKE blocks in the test output).

V0.11 requires a **repeated two-anchor pattern**: at least three vertically separated rows with stable left/right X anchors. A one-row coincidence can no longer create a table classification.

### 2. False two-column detection
V0.10 inferred columns from the largest gap between line-start X coordinates. Indentation and headings in an ordinary single-column document could therefore create artificial columns.

V0.11 requires persistent populations of line centres, strong separation, adequate population on both sides, low within-column spread, and substantial vertical coverage before declaring two columns.

### 3. Repository metadata entering the main reading stream
First-page institutional/repository material such as an institutional name, repository email, repository URL and ISO date is now recognized as source metadata when it occurs in the upper page area. It is kept out of the primary document flow.

### 4. Paragraph joining was too conservative
The vertical continuation allowance and indentation tolerance were increased moderately, while structural boundaries remain protected. This reduces one-line fragmentation without returning to uncontrolled global joining.

### 5. Numbered body lists being mistaken for headings
Numbered text is only promoted to a heading when it also satisfies heading-like length and punctuation conditions. List classification still takes precedence.

### 6. Structural self-check
The diagnostic now reports a structure-quality warning when TABLE_LIKE classification becomes disproportionately high. This makes the next test objectively measurable rather than relying only on visual inspection.

## Architecture

PDF spans → geometric cleanup → physical lines → furniture filtering → conservative spatial segmentation → region-local blocks → repeated-pattern structural analysis → reading order → diagnostics

Geometry and region membership remain available throughout the pipeline. EPUB serialization remains deliberately deferred until the reconstructed structure is reliable.

## Version

- `versionCode=11`
- `versionName=0.11`
- `applicationId=com.pdf_to_epub.v06` (unchanged for upgrade compatibility)

# PDF-to-EPUB V0.14 — Structural Repair Engine

V0.14 is the next diagnostic reconstruction release after V0.11. It is based on the observed V0.10/V0.11 output from the 12-page cancer-pathology test document.

## V0.14 fixes targeted by the test output

### 1. Flattened two-column/pair structures
Some repeated short left/right units were arriving as one physical text block, for example disease name → tissue type pairs. V0.14 conservatively recovers repeated embedded pairs as `TABLE_LIKE` rows when at least three known short right-column descriptors are matched and the matches cover a substantial portion of the block.

This is deliberately separate from the V0.11 multi-block table detector. The V0.10 one-neighbour table heuristic is not restored.

### 2. Attribution lines
Bare lines such as `Department of Pathology.` are classified as `SOURCE_NOTE` rather than ordinary body text.

### 3. Repository / Commons metadata
`Part of the Cancer Biology Commons` and related Commons/source wording are classified as source material and therefore excluded from the primary document stream.

### 4. Figure-caption variants
`Figures 1a, b.` and plural `Figures` forms are now recognized in addition to singular `Figure` forms.

### 5. Title promotion after structural repair
Title promotion now operates on the repaired block list, so structural splitting cannot silently discard a title promotion.

## Explicitly not reintroduced

- V0.9 global Y/X reading-order sort
- V0.10 one-neighbour `TABLE_LIKE` detection
- V0.10 largest-X-gap column detection
- EPUB serialization before structural validation

## Version

- `versionCode=12`
- `versionName=0.12`
- `applicationId=com.pdf_to_epub.v06` (unchanged for upgrade compatibility)

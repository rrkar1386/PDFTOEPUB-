# PDF-to-EPUB V0.10 — Spatial Reconstruction Engine

V0.10 replaces the V0.9 line/global-sort reconstruction approach with a region-first model.

## Pipeline

PDF spans → geometric cleanup → physical lines → furniture filtering → spatial regions → region-local blocks → structural classification → reading-order reconstruction

The critical invariant is that line/block geometry and region membership are retained until reading order is decided.

## Build

The included GitHub Actions workflow builds a debug APK with Java 17 and Gradle 8.9.

`versionCode=10`, `versionName=0.10`.

## Scope

This is the structural-analysis stage. EPUB generation is intentionally not added until the diagnostic reading order is reliable.

# PDF-to-EPUB V0.15 — Contextual Spatial Reconstruction

V0.15 is based directly on the recovered V0.12 structural engine and the corrected V0.14 spatial-relationship implementation. It does not use the broken V0.13 source.

## V0.15 focus
- Preserve V0.12's geometry → lines → regions → blocks → structural classification pipeline.
- Keep table relationships local to a single spatial region.
- Require compact, short cell-like blocks before allowing a table relationship.
- Reject tall/long prose blocks from the table detector.
- Preserve genuine repeated two-column rows such as disease → tissue mappings.
- Keep the existing embedded-pair recovery for flattened table text.
- Keep captions, source notes, references, and page furniture in their existing structural categories.

## Test target
The 12-page The Pathology of Cancer PDF remains the primary regression document. In particular, page 3 provides a negative case (ordinary prose aligned vertically), while page 5 provides a positive case (the repeated sarcoma/tissue two-column structure).

## Build
Java 17, Gradle 8.9, compileSdk 35, targetSdk 35, pdfbox-android 2.0.27.0.

## Identity
applicationId: com.pdf_to_epub.v06
versionCode: 15
versionName: 0.15

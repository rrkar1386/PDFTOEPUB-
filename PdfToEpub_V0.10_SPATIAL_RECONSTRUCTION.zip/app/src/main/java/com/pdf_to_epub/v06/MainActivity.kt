package com.pdf_to_epub.v06

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.InputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * PDF -> structural reconstruction prototype.
 *
 * V0.10 deliberately replaces the V0.9 line->global-sort->block pipeline.
 * The new model is:
 *
 * spans -> geometric cleanup -> physical lines -> page furniture filtering
 * -> spatial segmentation -> region-local blocks -> structural classification
 * -> document-level reading order.
 *
 * The important invariant is that geometry/region membership is never discarded
 * before reading order is decided.  This is a diagnostic reconstruction release;
 * EPUB writing is intentionally deferred until the structural model is reliable.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }
        val title = TextView(this).apply {
            text = "PDF → EPUB\nV0.10 — Spatial Reconstruction Engine"
            textSize = 28f
        }
        val select = Button(this).apply { text = "SELECT PDF" }
        val analyze = Button(this).apply { text = "ANALYZE + RECONSTRUCT" }
        output = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 0)
            setTextIsSelectable(true)
        }

        root.addView(title)
        root.addView(select)
        root.addView(analyze)
        root.addView(ScrollView(this).apply { addView(output) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        select.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, REQUEST_PDF
            )
        }
        analyze.setOnClickListener {
            selectedUri?.let { analyzePdf(it) } ?: run { output.text = "Please select a PDF first." }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PDF && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            try {
                data?.data?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            } catch (_: Exception) { }
            output.text = "Selected PDF:\n${selectedUri ?: ""}\n\nPress ANALYZE + RECONSTRUCT."
        }
    }

    private fun analyzePdf(uri: Uri) {
        output.text = "Running spatial reconstruction…"
        Thread {
            try {
                val result = contentResolver.openInputStream(uri)?.use { analyzeDocument(it) } ?: "Could not open PDF."
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Analysis error:\n${e.javaClass.simpleName}: ${e.message ?: "unknown error"}" }
            }
        }.start()
    }

    private fun analyzeDocument(input: InputStream): String {
        PDDocument.load(input).use { doc ->
            if (doc.numberOfPages == 0) return "PDF has no pages."

            val rawPages = mutableListOf<RawPage>()
            var rawGlyphs = 0
            var cleanedGlyphs = 0
            var duplicateGlyphs = 0
            var totalLines = 0

            for (pageNumber in 1..doc.numberOfPages) {
                val page = doc.getPage(pageNumber - 1)
                val stripper = LayoutStripper().apply {
                    startPage = pageNumber
                    endPage = pageNumber
                    sortByPosition = true
                }
                stripper.getText(doc)
                val raw = stripper.items
                val cleaned = deduplicateGeometrically(raw)
                val fragments = buildPhysicalLines(cleaned)
                rawGlyphs += raw.size
                cleanedGlyphs += cleaned.size
                duplicateGlyphs += raw.size - cleaned.size
                totalLines += fragments.size
                rawPages.add(RawPage(pageNumber, page.mediaBox.width, page.mediaBox.height, fragments))
            }

            val furniture = detectRunningFurniture(rawPages)
            val pages = rawPages.map { rawPage ->
                val filtered = rawPage.lines.filterNot { isFurnitureLine(it, rawPage.height, furniture) || isPageNumberText(it.text) }
                val regions = segmentPage(filtered, rawPage.width, rawPage.height)
                val assigned = filtered.map { line -> line.copy(regionId = assignRegion(line, regions)) }
                val blocks = buildBlocksByRegion(assigned, regions)
                val classified = classifyBlocks(blocks, rawPage.pageNumber, doc.numberOfPages, rawPage.width, rawPage.height)
                PageModel(rawPage.pageNumber, rawPage.width, rawPage.height, filtered, regions, classified)
            }

            return formatResult(doc.numberOfPages, rawGlyphs, cleanedGlyphs, duplicateGlyphs, totalLines, furniture, pages)
        }
    }

    // -------------------------- data model --------------------------

    enum class RegionKind { FULL_WIDTH, COLUMN_LEFT, COLUMN_RIGHT, SINGLE_COLUMN }

    data class Item(val text: String, val x: Float, val y: Float, val w: Float, val h: Float, val fontSize: Float)

    data class Line(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float,
        val regionId: String = ""
    )

    data class Region(
        val id: String,
        val kind: RegionKind,
        val left: Float,
        val right: Float,
        val top: Float,
        val bottom: Float
    )

    data class Block(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float,
        var lineCount: Int,
        val regionId: String
    )

    data class ClassifiedBlock(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float,
        val type: String,
        val confidence: String,
        val regionId: String,
        val relation: String = ""
    )

    data class RawPage(val pageNumber: Int, val width: Float, val height: Float, val lines: List<Line>)
    data class PageModel(val pageNumber: Int, val width: Float, val height: Float, val lines: List<Line>, val regions: List<Region>, val blocks: List<ClassifiedBlock>)

    class LayoutStripper : PDFTextStripper() {
        val items = mutableListOf<Item>()
        override fun processTextPosition(text: TextPosition) {
            val s = text.unicode ?: return
            if (s.isNotEmpty() && s.any { !it.isWhitespace() }) {
                items.add(Item(s, text.xDirAdj, text.yDirAdj, max(0.01f, text.widthDirAdj), max(0.01f, text.heightDir), max(1f, text.fontSizeInPt)))
            }
        }
    }

    // -------------------------- extraction --------------------------

    private fun deduplicateGeometrically(items: List<Item>): List<Item> {
        if (items.isEmpty()) return emptyList()
        val result = mutableListOf<Item>()
        val cells = HashMap<String, MutableList<Int>>()
        fun key(x: Float, y: Float) = "${(x / DUP_CELL).toInt()}:${(y / DUP_CELL).toInt()}"
        for (item in items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })) {
            val cx = (item.x / DUP_CELL).toInt()
            val cy = (item.y / DUP_CELL).toInt()
            var duplicate = false
            for (gx in cx - 1..cx + 1) for (gy in cy - 1..cy + 1) {
                cells["$gx:$gy"]?.forEach { idx -> if (sameGlyph(result[idx], item)) duplicate = true }
            }
            if (!duplicate) {
                val idx = result.size
                result.add(item)
                cells.getOrPut(key(item.x, item.y)) { mutableListOf() }.add(idx)
            }
        }
        return result
    }

    private fun sameGlyph(a: Item, b: Item): Boolean {
        if (a.text != b.text) return false
        if (abs(a.fontSize - b.fontSize) > max(1f, min(a.fontSize, b.fontSize) * 0.08f)) return false
        val xo = overlap(a.x, a.x + a.w, b.x, b.x + b.w)
        val yo = overlap(a.y, a.y + a.h, b.y, b.y + b.h)
        val minW = min(a.w, b.w)
        val minH = min(a.h, b.h)
        val centerDistance = abs(a.x + a.w / 2f - (b.x + b.w / 2f)) + abs(a.y + a.h / 2f - (b.y + b.h / 2f))
        return (xo >= minW * 0.55f && yo >= minH * 0.55f) || centerDistance <= 0.9f
    }

    /** Physical line construction. No column ordering is performed here. */
    private fun buildPhysicalLines(items: List<Item>): List<Line> {
        if (items.isEmpty()) return emptyList()
        val sorted = items.sortedWith(compareBy<Item> { it.y + it.h / 2f }.thenBy { it.x })
        val bands = mutableListOf<MutableList<Item>>()
        for (item in sorted) {
            val cy = item.y + item.h / 2f
            val target = bands.lastOrNull { band ->
                val avgCy = band.map { it.y + it.h / 2f }.average().toFloat()
                val avgH = band.map { it.h }.average().toFloat()
                abs(cy - avgCy) <= max(1.8f, avgH * 0.45f)
            }
            if (target == null) bands.add(mutableListOf(item)) else target.add(item)
        }

        val result = mutableListOf<Line>()
        for (band in bands) {
            val ordered = band.sortedBy { it.x }
            if (ordered.isEmpty()) continue
            val medianFont = median(ordered.map { it.fontSize })
            val splitThreshold = max(22f, medianFont * 3.4f)
            val groups = mutableListOf<MutableList<Item>>()
            var current = mutableListOf<Item>()
            ordered.forEachIndexed { i, item ->
                if (i > 0) {
                    val gap = item.x - (ordered[i - 1].x + ordered[i - 1].w)
                    if (gap > splitThreshold && current.isNotEmpty()) {
                        groups.add(current)
                        current = mutableListOf()
                    }
                }
                current.add(item)
            }
            if (current.isNotEmpty()) groups.add(current)
            groups.forEach { group ->
                val text = buildText(group)
                val left = group.minOf { it.x }
                val right = group.maxOf { it.x + it.w }
                val top = group.minOf { it.y }
                val bottom = group.maxOf { it.y + it.h }
                result.add(Line(text, left, top, right - left, bottom - top, median(group.map { it.fontSize })))
            }
        }
        return result.sortedWith(compareBy<Line> { it.y }.thenBy { it.x })
    }

    private fun buildText(items: List<Item>): String {
        val ordered = items.sortedBy { it.x }
        val out = StringBuilder()
        var previous: Item? = null
        for (item in ordered) {
            if (previous != null) {
                val gap = item.x - (previous.x + previous.w)
                if (gap > max(1f, min(item.fontSize, previous.fontSize) * 0.20f)) out.append(' ')
            }
            out.append(item.text)
            previous = item
        }
        return cleanSpacing(out.toString())
    }

    // -------------------------- furniture --------------------------

    private fun detectRunningFurniture(pages: List<RawPage>): Set<String> {
        if (pages.size < 2) return emptySet()
        val occurrences = HashMap<String, MutableSet<Int>>()
        pages.forEach { page ->
            page.lines.filter { it.y <= page.height * 0.15f || it.y + it.h >= page.height * 0.86f }
                .forEach { line ->
                    val key = normalizeForKey(line.text)
                    if (key.length in 3..120) occurrences.getOrPut(key) { mutableSetOf() }.add(page.pageNumber)
                }
        }
        val threshold = max(2, min(4, pages.size / 2))
        return occurrences.filterValues { it.size >= threshold }.keys
    }

    private fun isFurnitureLine(line: Line, pageHeight: Float, furniture: Set<String>): Boolean {
        val key = normalizeForKey(line.text)
        if (key.isEmpty() || !furniture.contains(key)) return false
        return line.y <= pageHeight * 0.15f || line.y + line.h >= pageHeight * 0.86f
    }

    private fun isPageNumberText(text: String): Boolean =
        Regex("^(?:page\\s+)?\\d{1,4}$", RegexOption.IGNORE_CASE).matches(text.trim())

    // -------------------------- spatial segmentation --------------------------

    /**
     * Region detection is based on persistent whitespace across the page rather
     * than a single line-start gap. Full-width lines are kept separate so a
     * heading or a full-width paragraph can act as a reading-order barrier.
     */
    private fun segmentPage(lines: List<Line>, pageWidth: Float, pageHeight: Float): List<Region> {
        if (lines.isEmpty()) return listOf(Region("single", RegionKind.SINGLE_COLUMN, 0f, pageWidth, 0f, pageHeight))

        val narrow = lines.filter { it.w < pageWidth * 0.78f }
        if (narrow.size < 10) return listOf(Region("single", RegionKind.SINGLE_COLUMN, 0f, pageWidth, 0f, pageHeight))

        val starts = narrow.map { it.x }.sorted()
        var bestGap = 0f
        var bestBoundary = 0f
        for (i in 0 until starts.lastIndex) {
            val gap = starts[i + 1] - starts[i]
            if (gap > bestGap) {
                bestGap = gap
                bestBoundary = (starts[i + 1] + starts[i]) / 2f
            }
        }

        val strongGap = bestGap >= max(48f, pageWidth * 0.10f)
        if (!strongGap) return listOf(Region("single", RegionKind.SINGLE_COLUMN, 0f, pageWidth, 0f, pageHeight))

        val left = narrow.filter { it.x < bestBoundary }
        val right = narrow.filter { it.x >= bestBoundary }
        if (left.size < 5 || right.size < 5) return listOf(Region("single", RegionKind.SINGLE_COLUMN, 0f, pageWidth, 0f, pageHeight))

        val leftSpan = verticalSpan(left)
        val rightSpan = verticalSpan(right)
        if (leftSpan < pageHeight * 0.24f || rightSpan < pageHeight * 0.24f) {
            return listOf(Region("single", RegionKind.SINGLE_COLUMN, 0f, pageWidth, 0f, pageHeight))
        }

        return listOf(
            Region("full", RegionKind.FULL_WIDTH, 0f, pageWidth, 0f, pageHeight),
            Region("left", RegionKind.COLUMN_LEFT, 0f, bestBoundary, 0f, pageHeight),
            Region("right", RegionKind.COLUMN_RIGHT, bestBoundary, pageWidth, 0f, pageHeight)
        )
    }

    private fun assignRegion(line: Line, regions: List<Region>): String {
        val full = regions.firstOrNull { it.kind == RegionKind.FULL_WIDTH }
        if (full == null) return regions.first().id
        if (line.w >= (regions.maxOf { it.right } - regions.minOf { it.left }) * 0.72f) return full.id
        val left = regions.firstOrNull { it.kind == RegionKind.COLUMN_LEFT }
        val right = regions.firstOrNull { it.kind == RegionKind.COLUMN_RIGHT }
        if (left != null && right != null) {
            val center = line.x + line.w / 2f
            return if (center < (left.right + right.left) / 2f) left.id else right.id
        }
        return full.id
    }

    private fun verticalSpan(lines: List<Line>): Float =
        if (lines.isEmpty()) 0f else lines.maxOf { it.y + it.h } - lines.minOf { it.y }

    // -------------------------- block reconstruction --------------------------

    /** Build paragraphs only within the same spatial region. */
    private fun buildBlocksByRegion(lines: List<Line>, regions: List<Region>): List<Block> {
        val result = mutableListOf<Block>()
        regions.forEach { region ->
            val regionLines = lines.filter { it.regionId == region.id }
                .sortedWith(compareBy<Line> { it.y }.thenBy { it.x })
            val blocks = mutableListOf<Block>()
            for (line in regionLines) {
                val previous = blocks.lastOrNull()
                if (previous != null && canJoin(previous, line)) {
                    previous.text = joinParagraph(previous.text, line.text)
                    previous.w = max(previous.w, line.x + line.w - previous.x)
                    previous.h = max(previous.h, line.y + line.h - previous.y)
                    previous.fontSize = (previous.fontSize + line.fontSize) / 2f
                    previous.lineCount++
                } else {
                    blocks.add(Block(line.text, line.x, line.y, line.w, line.h, line.fontSize, 1, region.id))
                }
            }
            result.addAll(blocks)
        }
        return result
    }

    private fun canJoin(previous: Block, line: Line): Boolean {
        val gap = line.y - (previous.y + previous.h)
        val sameFont = abs(line.fontSize - previous.fontSize) <= max(1.4f, previous.fontSize * 0.12f)
        val indent = abs(line.x - previous.x)
        val overlapX = overlap(previous.x, previous.x + previous.w, line.x, line.x + line.w)
        val paragraphGap = max(7f, previous.fontSize * 0.80f)
        if (!sameFont || gap < -previous.h * 0.25f || gap > paragraphGap) return false
        if (isStandaloneStructure(line.text) || isStandaloneStructure(previous.text)) return false
        // A continuation normally overlaps the previous text width or begins near its left edge.
        return indent <= max(14f, previous.fontSize * 2.2f) || overlapX > min(previous.w, line.w) * 0.35f
    }

    private fun isStandaloneStructure(text: String): Boolean =
        isListItem(text) || isReferenceItem(text) || isReferenceSection(text) || isFigureCaption(text) || isTableHeaderLike(text)

    // -------------------------- structural classification --------------------------

    private fun classifyBlocks(blocks: List<Block>, pageNumber: Int, pageCount: Int, pageWidth: Float, pageHeight: Float): List<ClassifiedBlock> {
        if (blocks.isEmpty()) return emptyList()
        val bodyFont = median(blocks.map { it.fontSize })
        val styleProfile = StyleProfile(bodyFont, blocks.map { it.fontSize }.distinct().sorted())
        val classified = blocks.mapIndexed { index, block ->
            val text = cleanSpacing(block.text)
            val typeAndConfidence = classifyOne(text, block, index, blocks, styleProfile, pageNumber, pageCount, pageWidth, pageHeight)
            ClassifiedBlock(text, block.x, block.y, block.w, block.h, block.fontSize, typeAndConfidence.first, typeAndConfidence.second, block.regionId)
        }.toMutableList()

        // Only promote a first-page heading that is genuinely title-like. Never promote a body paragraph merely because it is large.
        if (pageNumber == 1) {
            val candidate = classified.indices
                .filter { classified[it].type in setOf("HEADING", "SUBHEADING") }
                .filter { classified[it].text.length in 5..140 }
                .maxByOrNull { titleScore(classified[it], pageWidth, pageHeight) }
            if (candidate != null && titleScore(classified[candidate], pageWidth, pageHeight) >= 1.8f) {
                classified[candidate] = classified[candidate].copy(type = "TITLE", confidence = "HIGH")
            }
        }
        return classified
    }

    data class StyleProfile(val bodyFont: Float, val sizes: List<Float>)

    private fun classifyOne(
        text: String,
        block: Block,
        index: Int,
        blocks: List<Block>,
        style: StyleProfile,
        page: Int,
        pageCount: Int,
        pageWidth: Float,
        pageHeight: Float
    ): Pair<String, String> {
        val lower = text.lowercase(Locale.US)
        return when {
            isReferenceSection(text) -> "HEADING" to "HIGH"
            isFigureCaption(text) -> "FIGURE_CAPTION" to "HIGH"
            isTableLikeGeometry(blocks, block) -> "TABLE_LIKE" to "HIGH"
            isListItem(text) -> "LIST_ITEM" to "HIGH"
            isReferenceItem(text) -> "REFERENCE_ITEM" to "HIGH"
            isPageNumberText(text) -> "PAGE_NUMBER" to "HIGH"
            isSourceOrCitation(text) -> "SOURCE_NOTE" to "MEDIUM"
            isHeading(text, block, style, index, blocks, pageWidth) -> "HEADING" to "HIGH"
            isAuthorLine(text) && page == 1 -> "AUTHOR" to "HIGH"
            isNotice(text) -> "NOTICE" to "MEDIUM"
            lower.contains("creative commons") || lower.contains("licensed under") -> "LICENSE" to "HIGH"
            else -> "BODY" to "HIGH"
        }
    }

    private fun isHeading(text: String, block: Block, style: StyleProfile, index: Int, blocks: List<Block>, pageWidth: Float): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.length > 180 || isListItem(t) || isReferenceItem(t) || isFigureCaption(t)) return false
        val numbered = Regex("^(?:\\d+(?:\\.\\d+)*[.)]?|[IVX]+[.)])\\s+.+", RegexOption.IGNORE_CASE).matches(t)
        val short = t.length <= 100
        val fontLift = block.fontSize >= style.bodyFont * 1.10f
        val strongFontLift = block.fontSize >= style.bodyFont * 1.25f
        val noSentencePunctuation = !t.endsWith(".") && !t.endsWith(",") && !t.endsWith(";")
        val spacing = headingSpacing(index, blocks)
        val fullWidth = block.w >= pageWidth * 0.55f
        return numbered || (short && noSentencePunctuation && (strongFontLift || (fontLift && spacing)) && (fullWidth || spacing))
    }

    private fun headingSpacing(index: Int, blocks: List<Block>): Boolean {
        val current = blocks[index]
        val before = if (index > 0) current.y - (blocks[index - 1].y + blocks[index - 1].h) else 20f
        val after = if (index + 1 < blocks.size) blocks[index + 1].y - (current.y + current.h) else 20f
        return before >= max(9f, current.fontSize * 0.75f) || after >= max(9f, current.fontSize * 0.75f)
    }

    private fun titleScore(block: ClassifiedBlock, pageWidth: Float, pageHeight: Float): Float {
        var score = 0f
        if (block.fontSize >= 16f) score += 1f
        if (block.fontSize >= 20f) score += 0.7f
        if (block.w >= pageWidth * 0.45f) score += 0.5f
        if (block.y <= pageHeight * 0.35f) score += 0.5f
        if (block.text.length <= 100) score += 0.3f
        return score
    }

    // -------------------------- table / caption / source detection --------------------------

    /** Geometry-based table detection; never relies on preserved multiple spaces. */
    private fun isTableLikeGeometry(blocks: List<Block>, current: Block): Boolean {
        val peers = blocks.filter { it !== current && abs(it.fontSize - current.fontSize) <= max(1.4f, current.fontSize * 0.15f) }
        val aligned = peers.count { other ->
            val yClose = abs(other.y - current.y) <= max(3f, current.fontSize * 0.55f)
            val separatedX = abs(other.x - current.x) >= max(45f, current.fontSize * 4f)
            yClose && separatedX
        }
        return aligned >= 1 && current.text.length <= 100 && !current.text.contains(". ")
    }

    private fun isTableHeaderLike(text: String): Boolean {
        val t = text.trim()
        return t.length <= 80 && !t.endsWith(".") && !isListItem(t) && !isFigureCaption(t)
    }

    private fun isFigureCaption(text: String): Boolean =
        Regex("^(figure|fig\\.?|table)\\s*\\d+[a-z]?(?:\\s*[,.:)]|\\s).+", RegexOption.IGNORE_CASE).containsMatchIn(text.trim())

    private fun isReferenceSection(text: String): Boolean =
        Regex("^(references|bibliography|works cited)$", RegexOption.IGNORE_CASE).matches(text.trim())

    private fun isReferenceItem(text: String): Boolean =
        Regex("^\\d+[.)]\\s+.+").matches(text.trim()) && text.length >= 25 && (text.contains(".") || text.contains("et al", true))

    private fun isListItem(text: String): Boolean =
        Regex("^(?:\\d+[.)]|[•▪◦–—-])\\s+.+").matches(text.trim())

    private fun isSourceOrCitation(text: String): Boolean {
        val t = text.lowercase(Locale.US)
        return t.contains("citation:") || t.contains("retrieved from") || t.contains("doi.org/") ||
            t.startsWith("cancer concepts:") || t.contains("images courtesy of") || t.contains("source:")
    }

    private fun isNotice(text: String): Boolean {
        val t = text.lowercase(Locale.US)
        return t.startsWith("let us know how access") || t.startsWith("follow this and additional works")
    }

    // -------------------------- reading order --------------------------

    /**
     * Reading order is generated from blocks and their spatial regions. A full-
     * width block is a barrier; within each barrier interval, left-column blocks
     * precede right-column blocks. This prevents the V0.9 global Y/X sort from
     * interleaving columns and prevents a paragraph from crossing regions.
     */
    private fun documentReadingOrder(pages: List<PageModel>): List<ClassifiedBlock> {
        val out = mutableListOf<ClassifiedBlock>()
        pages.forEach { page -> out.addAll(pageReadingOrder(page)) }
        return out
    }

    private fun pageReadingOrder(page: PageModel): List<ClassifiedBlock> {
        val blocks = page.blocks.filterNot { it.type in setOf("PAGE_NUMBER", "RUNNING_HEADER", "RUNNING_FOOTER") }
        if (blocks.isEmpty()) return emptyList()
        val hasColumns = page.regions.any { it.kind == RegionKind.COLUMN_LEFT } && page.regions.any { it.kind == RegionKind.COLUMN_RIGHT }
        if (!hasColumns) return blocks.sortedBy { it.y }

        val full = blocks.filter { it.regionId == "full" }.sortedBy { it.y }
        val columns = blocks.filter { it.regionId == "left" || it.regionId == "right" }
        if (columns.isEmpty()) return full

        val result = mutableListOf<ClassifiedBlock>()
        var cursor = 0f
        val barriers = full
        for (barrier in barriers) {
            val before = columns.filter { it.y >= cursor && it.y < barrier.y }
            result.addAll(columnFlow(before))
            result.add(barrier)
            cursor = barrier.y + barrier.h
        }
        result.addAll(columnFlow(columns.filter { it.y >= cursor }))
        return result
    }

    private fun columnFlow(blocks: List<ClassifiedBlock>): List<ClassifiedBlock> {
        val left = blocks.filter { it.regionId == "left" }.sortedBy { it.y }
        val right = blocks.filter { it.regionId == "right" }.sortedBy { it.y }
        return left + right
    }

    // -------------------------- diagnostics --------------------------

    private fun formatResult(
        pageCount: Int,
        rawGlyphs: Int,
        cleanedGlyphs: Int,
        duplicateGlyphs: Int,
        totalLines: Int,
        furniture: Set<String>,
        pages: List<PageModel>
    ): String {
        val reading = documentReadingOrder(pages)
        val counts = reading.groupingBy { it.type }.eachCount()
        val primary = reading.filter { it.type !in FRONT_MATTER_TYPES }
        val front = reading.filter { it.type in FRONT_MATTER_TYPES }

        val sb = StringBuilder()
        sb.append("Pages: $pageCount\n")
        sb.append("Analyzed pages: $pageCount\n")
        sb.append("Raw glyph items: $rawGlyphs\n")
        sb.append("After geometric cleanup: $cleanedGlyphs\n")
        sb.append("Geometric duplicates removed: $duplicateGlyphs\n")
        sb.append("Physical lines: $totalLines\n")
        sb.append("Structural blocks: ${reading.size}\n")
        sb.append("Running furniture suppressed: ${furniture.size}\n")
        sb.append("\nSTRUCTURAL COUNTS\n")
        counts.toSortedMap().forEach { (k, v) -> sb.append("$k: $v\n") }

        sb.append("\nDOCUMENT READING ORDER\n")
        sb.append("======================\n")
        if (primary.isEmpty()) sb.append("No primary document blocks detected.\n")
        primary.forEach { b ->
            when (b.type) {
                "TITLE", "HEADING", "SUBHEADING" -> sb.append("\n${b.text}\n")
                "TABLE_LIKE" -> sb.append("[TABLE-LIKE] ${b.text}\n")
                "FIGURE_CAPTION" -> sb.append("[CAPTION] ${b.text}\n")
                "SOURCE_NOTE" -> sb.append("[SOURCE] ${b.text}\n")
                else -> sb.append("${b.text}\n")
            }
        }

        sb.append("\nREPOSITORY / SOURCE MATERIAL\n")
        sb.append("============================\n")
        if (front.isEmpty()) sb.append("None detected.\n")
        front.forEach { b -> sb.append("[${b.type}] ${b.text}\n") }

        sb.append("\nSPATIAL RECONSTRUCTION DIAGNOSTICS\n")
        sb.append("=================================\n")
        pages.forEach { page ->
            sb.append("\nPAGE ${page.pageNumber}  ${fmt(page.width)}×${fmt(page.height)}\n")
            sb.append("Regions: ")
            sb.append(page.regions.joinToString { "${it.id}:${it.kind}" })
            sb.append("\n")
            page.blocks.sortedWith(compareBy<ClassifiedBlock> { it.y }.thenBy { it.x }).forEachIndexed { i, b ->
                sb.append("BLOCK ${i + 1} [${b.regionId}] ${b.type} (${b.confidence})\n")
                sb.append("x=${fmt(b.x)} y=${fmt(b.y)} w=${fmt(b.w)} h=${fmt(b.h)} font=${fmt(b.fontSize)}\n")
                sb.append("${b.text}\n\n")
            }
        }
        return sb.toString()
    }

    // -------------------------- helpers --------------------------

    private fun cleanSpacing(text: String): String = text.replace(Regex("\\s+"), " ").trim()

    private fun joinParagraph(a: String, b: String): String {
        val left = a.trimEnd()
        val right = b.trimStart()
        if (left.endsWith("-") && right.firstOrNull()?.isLetter() == true) return left.dropLast(1) + right
        return "$left $right"
    }

    private fun normalizeForKey(text: String): String =
        text.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), " ").trim()

    private fun isAuthorLine(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        if (lower.contains("@") || lower == "et al.") return false
        if (lower.startsWith("by ")) return true
        return Regex("\\b(?:md|phd|ba|ma|rn|do|et al\\.?)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) && text.length <= 140
    }

    private fun isSourceLikeFirstPage(text: String): Boolean =
        text.lowercase(Locale.US).contains("cancer concepts: a guidebook for the non-oncologist")

    private fun overlap(a1: Float, a2: Float, b1: Float, b2: Float): Float = max(0f, min(a2, b2) - max(a1, b1))

    private fun median(values: List<Float>): Float {
        if (values.isEmpty()) return 10f
        val s = values.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.1f", v)

    companion object {
        private const val REQUEST_PDF = 100
        private const val DUP_CELL = 3.0f
        private val FRONT_MATTER_TYPES = setOf("SOURCE_NOTE", "NOTICE", "LICENSE", "AUTHOR")
    }
}

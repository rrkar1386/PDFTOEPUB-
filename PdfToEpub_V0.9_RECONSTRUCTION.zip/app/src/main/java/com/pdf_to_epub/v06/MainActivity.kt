package com.pdf_to_epub.v06

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.InputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * PDF -> structural analysis prototype.
 *
 * V0.9 is a reconstruction release.  The key change is that structural
 * classification no longer operates on an untrusted stream of PDF glyphs.
 * The pipeline is now:
 *
 * glyphs -> geometric duplicate removal -> line reconstruction -> page
 * regions/columns -> block reconstruction -> repeated-header/footer removal
 * -> structural classification -> document reading order.
 *
 * This deliberately remains a diagnostic prototype: it does not write EPUB.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB\nV0.9 — Reconstruction + structural analysis"
            textSize = 28f
        }

        val select = Button(this).apply { text = "SELECT PDF" }
        val analyze = Button(this).apply { text = "ANALYZE + RECONSTRUCT" }

        output = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 0)
            setTextIsSelectable(true)
        }

        root.addView(title)
        root.addView(select)
        root.addView(analyze)
        root.addView(
            ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 0, 1f)
        )
        setContentView(root)

        select.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    )
                }, REQUEST_PDF
            )
        }

        analyze.setOnClickListener {
            selectedUri?.let { analyzePdf(it) }
                ?: run { output.text = "Please select a PDF first." }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PDF && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            try {
                data?.data?.let {
                    contentResolver.takePersistableUriPermission(
                        it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            } catch (_: Exception) {
                // Some document providers do not support persistable permissions.
            }
            output.text = "Selected PDF:\n${selectedUri ?: ""}\n\nPress ANALYZE + RECONSTRUCT."
        }
    }

    private fun analyzePdf(uri: Uri) {
        output.text = "Reconstructing text, layout and document order…"
        Thread {
            try {
                val result = contentResolver.openInputStream(uri)?.use { analyzeDocument(it) }
                    ?: "Could not open PDF."
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread {
                    output.text = "Analysis error:\n${e.javaClass.simpleName}: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun analyzeDocument(input: InputStream): String {
        PDDocument.load(input).use { doc ->
            if (doc.numberOfPages == 0) return "PDF has no pages."

            val pages = mutableListOf<PageAnalysis>()
            var rawCount = 0
            var duplicateCount = 0
            var lineCount = 0
            var blockCount = 0

            for (pageNumber in 1..doc.numberOfPages) {
                val page = doc.getPage(pageNumber - 1)
                val stripper = LayoutStripper()
                stripper.startPage = pageNumber
                stripper.endPage = pageNumber
                stripper.sortByPosition = true
                stripper.getText(doc)

                val raw = stripper.items
                val cleaned = deduplicateGeometrically(raw)
                val fragments = buildLineFragments(cleaned)
                val lines = orderAndMergeColumns(fragments, page.mediaBox.width)
                val blocks = buildBlocks(lines)

                rawCount += raw.size
                duplicateCount += raw.size - cleaned.size
                lineCount += lines.size
                blockCount += blocks.size
                pages.add(
                    PageAnalysis(
                        pageNumber = pageNumber,
                        pageWidth = page.mediaBox.width,
                        pageHeight = page.mediaBox.height,
                        lines = lines,
                        rawBlocks = blocks,
                        blocks = emptyList()
                    )
                )
            }

            val repeated = detectRepeatedFurniture(pages)
            val classifiedPages = pages.map { page ->
                val withoutFurniture = page.rawBlocks.filterNot { isRepeatedFurnitureBlock(it, page.pageHeight, repeated) }
                val classified = classifyPageBlocks(withoutFurniture, page.pageNumber, pages.size)
                page.copy(blocks = classified)
            }

            return formatResult(
                doc.numberOfPages,
                rawCount,
                rawCount - duplicateCount,
                duplicateCount,
                lineCount,
                blockCount,
                repeated,
                classifiedPages
            )
        }
    }

    private fun formatResult(
        pageCount: Int,
        rawCount: Int,
        cleanedCount: Int,
        duplicateCount: Int,
        lineCount: Int,
        blockCount: Int,
        repeatedFurniture: Set<String>,
        pages: List<PageAnalysis>
    ): String {
        val allBlocks = pages.flatMap { it.blocks }
        val primary = allBlocks.filter { it.type !in FRONT_MATTER_TYPES && it.type != "PAGE_NUMBER" && it.type != "RUNNING_HEADER" && it.type != "RUNNING_FOOTER" }
        val frontMatter = allBlocks.filter { it.type in FRONT_MATTER_TYPES }

        val sb = StringBuilder()
        sb.append("Pages: $pageCount\n")
        sb.append("Analyzed pages: $pageCount\n")
        sb.append("Raw glyph items: $rawCount\n")
        sb.append("After geometric cleanup: $cleanedCount\n")
        sb.append("Geometric duplicates removed: $duplicateCount\n")
        sb.append("Reconstructed lines: $lineCount\n")
        sb.append("Reconstructed blocks: $blockCount\n")
        sb.append("Repeated header/footer candidates suppressed: ${repeatedFurniture.size}\n\n")

        sb.append("DOCUMENT READING ORDER\n")
        sb.append("----------------------\n")
        if (primary.isEmpty()) {
            sb.append("No primary document blocks detected.\n")
        } else {
            primary.forEach { b ->
                when (b.type) {
                    "TITLE", "HEADING", "SUBHEADING" -> sb.append("\n${b.text.trim()}\n")
                    "LIST_ITEM", "REFERENCE_ITEM" -> sb.append(b.text.trim()).append('\n')
                    "TABLE_LIKE" -> sb.append(b.text.trim()).append('\n')
                    else -> sb.append(b.text.trim()).append('\n')
                }
            }
        }

        sb.append("\nREPOSITORY / FRONT-MATTER (KEPT SEPARATE)\n")
        sb.append("-----------------------------------------\n")
        if (frontMatter.isEmpty()) {
            sb.append("None detected.\n")
        } else {
            frontMatter.forEach { b ->
                sb.append("[${b.type}] ${b.text.trim()}\n")
            }
        }

        sb.append("\nSTRUCTURAL DIAGNOSTICS\n")
        sb.append("----------------------\n")
        sb.append("The document is reconstructed page-by-page before classification.\n")
        sb.append("Repeated furniture keys: ${if (repeatedFurniture.isEmpty()) "none" else repeatedFurniture.joinToString(" | ")}\n\n")

        pages.forEach { page ->
            sb.append("PAGE ${page.pageNumber}\n")
            page.blocks.forEachIndexed { i, b ->
                sb.append("BLOCK ${i + 1}\n")
                sb.append("TYPE: ${b.type}\n")
                sb.append("CONFIDENCE: ${b.confidence}\n")
                sb.append("x=${fmt(b.x)}  y=${fmt(b.y)}  w=${fmt(b.w)}  h=${fmt(b.h)}\n")
                sb.append("font≈${fmt(b.fontSize)}\n")
                sb.append("text: ${b.text.trim()}\n\n")
            }
        }
        return sb.toString()
    }

    data class PageAnalysis(
        val pageNumber: Int,
        val pageWidth: Float,
        val pageHeight: Float,
        val lines: List<Line>,
        val rawBlocks: List<Block>,
        val blocks: List<ClassifiedBlock>
    )

    data class Item(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float
    )

    data class LineFragment(
        val items: List<Item>,
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float
    )

    data class Line(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    data class Block(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float,
        var lineCount: Int = 1
    )

    data class ClassifiedBlock(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float,
        val type: String,
        val confidence: String
    )

    class LayoutStripper : PDFTextStripper() {
        val items = mutableListOf<Item>()

        override fun processTextPosition(text: TextPosition) {
            val s = text.unicode ?: return
            if (s.isNotEmpty() && s.any { !it.isWhitespace() }) {
                items.add(
                    Item(
                        text = s,
                        x = text.xDirAdj,
                        y = text.yDirAdj,
                        w = max(0.01f, text.widthDirAdj),
                        h = max(0.01f, text.heightDir),
                        fontSize = max(1f, text.fontSizeInPt)
                    )
                )
            }
        }
    }

    /** Remove duplicate glyphs by physical overlap, not by text alone. */
    private fun deduplicateGeometrically(items: List<Item>): List<Item> {
        if (items.isEmpty()) return emptyList()
        val result = mutableListOf<Item>()
        val cells = HashMap<String, MutableList<Int>>()

        fun cell(x: Float, y: Float): String = "${(x / DUP_CELL).toInt()}:${(y / DUP_CELL).toInt()}"

        for (item in items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })) {
            val cx = (item.x / DUP_CELL).toInt()
            val cy = (item.y / DUP_CELL).toInt()
            var duplicate = false
            for (gx in (cx - 1)..(cx + 1)) {
                for (gy in (cy - 1)..(cy + 1)) {
                    cells["$gx:$gy"]?.forEach { idx ->
                        if (sameGlyph(result[idx], item)) duplicate = true
                    }
                }
            }
            if (!duplicate) {
                val index = result.size
                result.add(item)
                cells.getOrPut(cell(item.x, item.y)) { mutableListOf() }.add(index)
            }
        }
        return result
    }

    private fun sameGlyph(a: Item, b: Item): Boolean {
        if (a.text != b.text) return false
        if (abs(a.fontSize - b.fontSize) > max(1.0f, min(a.fontSize, b.fontSize) * 0.08f)) return false
        val xOverlap = overlap(a.x, a.x + a.w, b.x, b.x + b.w)
        val yOverlap = overlap(a.y, a.y + a.h, b.y, b.y + b.h)
        val minW = min(a.w, b.w)
        val minH = min(a.h, b.h)
        val centerDistance = abs((a.x + a.w / 2f) - (b.x + b.w / 2f)) +
            abs((a.y + a.h / 2f) - (b.y + b.h / 2f))
        return (xOverlap >= minW * 0.55f && yOverlap >= minH * 0.55f) || centerDistance <= 0.9f
    }

    private fun buildLineFragments(items: List<Item>): List<LineFragment> {
        if (items.isEmpty()) return emptyList()
        val sorted = items.sortedWith(compareBy<Item> { it.y + it.h / 2f }.thenBy { it.x })
        val bands = mutableListOf<MutableList<Item>>()

        for (item in sorted) {
            val cy = item.y + item.h / 2f
            val target = bands.lastOrNull { band ->
                val avgCy = band.map { it.y + it.h / 2f }.average().toFloat()
                val avgH = band.map { it.h }.average().toFloat()
                abs(cy - avgCy) <= max(1.8f, avgH * 0.45f)
            }
            if (target == null) bands.add(mutableListOf(item)) else target.add(item)
        }

        val fragments = mutableListOf<LineFragment>()
        for (band in bands) {
            val ordered = band.sortedBy { it.x }
            if (ordered.isEmpty()) continue

            // Split a y-band at unusually large horizontal gaps.  This prevents
            // two columns or table-like pairs at the same y from being welded
            // into one sentence, while normal word gaps remain intact.
            val gaps = ordered.zipWithNext().map { (a, b) ->
                b.x - (a.x + a.w)
            }
            val medianFont = ordered.map { it.fontSize }.sorted()[ordered.size / 2]
            val splitThreshold = max(24f, medianFont * 3.8f)
            val groups = mutableListOf<MutableList<Item>>()
            var current = mutableListOf<Item>()
            ordered.forEachIndexed { index, item ->
                if (index > 0 && gaps[index - 1] > splitThreshold && current.isNotEmpty()) {
                    groups.add(current)
                    current = mutableListOf()
                }
                current.add(item)
            }
            if (current.isNotEmpty()) groups.add(current)

            groups.forEach { group ->
                fragments.add(makeFragment(group))
            }
        }
        return fragments.sortedWith(compareBy<LineFragment> { it.y }.thenBy { it.x })
    }

    private fun makeFragment(items: List<Item>): LineFragment {
        val ordered = items.sortedBy { it.x }
        val text = StringBuilder()
        var previous: Item? = null
        for (c in ordered) {
            if (previous != null) {
                val gap = c.x - (previous.x + previous.w)
                val threshold = max(1.0f, min(c.fontSize, previous.fontSize) * 0.20f)
                if (gap > threshold) {
                    text.append(if (gap > max(8f, min(c.fontSize, previous.fontSize) * 1.8f)) "  " else " ")
                }
            }
            text.append(c.text)
            previous = c
        }
        val left = ordered.minOf { it.x }
        val right = ordered.maxOf { it.x + it.w }
        val top = ordered.minOf { it.y }
        val bottom = ordered.maxOf { it.y + it.h }
        return LineFragment(
            items = ordered,
            text = text.toString().trim(),
            x = left,
            y = top,
            w = right - left,
            h = bottom - top,
            fontSize = ordered.map { it.fontSize }.average().toFloat()
        )
    }

    private fun orderAndMergeColumns(fragments: List<LineFragment>, pageWidth: Float): List<Line> {
        if (fragments.isEmpty()) return emptyList()

        // Detect a stable vertical gutter from line starts.  This is intentionally
        // conservative: only a large, repeated x-gap becomes a column boundary.
        val starts = fragments.map { it.x }.sorted()
        val candidateGaps = starts.zipWithNext().mapIndexed { i, pair ->
            val gap = pair.second - pair.first
            Triple(i, gap, pair.first)
        }
        val medianFont = median(fragments.map { it.fontSize })
        val gutter = candidateGaps
            .filter { it.second >= max(70f, medianFont * 8f) && it.second <= pageWidth * 0.45f }
            .maxByOrNull { it.second }

        val columns: List<List<LineFragment>> = if (gutter != null) {
            val boundary = (gutter.third + gutter.second / 2f)
            val left = fragments.filter { it.x < boundary }
            val right = fragments.filter { it.x >= boundary }
            if (left.size >= 4 && right.size >= 4) listOf(left, right) else listOf(fragments)
        } else {
            listOf(fragments)
        }

        val ordered = columns.flatMap { column ->
            column.sortedWith(compareBy<LineFragment> { it.y }.thenBy { it.x })
        }

        val result = mutableListOf<Line>()
        for (fragment in ordered) {
            val previous = result.lastOrNull()
            if (previous != null &&
                abs(fragment.y - previous.y) <= max(2.0f, min(fragment.h, previous.h) * 0.55f) &&
                fragment.x <= previous.x + previous.w + max(8f, fragment.fontSize * 1.1f)
            ) {
                val gap = fragment.x - (previous.x + previous.w)
                if (gap <= max(10f, fragment.fontSize * 2.5f)) {
                    previous.text = cleanSpacing(previous.text + " " + fragment.text)
                    val right = fragment.x + fragment.w
                    previous.w = max(previous.w, right - previous.x)
                    previous.h = max(previous.h, fragment.y + fragment.h - previous.y)
                    previous.fontSize = (previous.fontSize + fragment.fontSize) / 2f
                    continue
                }
            }
            result.add(Line(fragment.text.trim(), fragment.x, fragment.y, fragment.w, fragment.h, fragment.fontSize))
        }
        return result
    }

    private fun looksLikeStandaloneStructure(text: String): Boolean {
        val t = text.trim()
        return isListItem(t) || isReferenceItem(t) || isReferenceSection(t) ||
            isFigureCaption(t) || Regex("^(figure|fig\\.?|table)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)
    }

    private fun buildBlocks(lines: List<Line>): List<Block> {
        if (lines.isEmpty()) return emptyList()
        val blocks = mutableListOf<Block>()
        for (line in lines.sortedWith(compareBy<Line> { it.y }.thenBy { it.x })) {
            val previous = blocks.lastOrNull()
            if (previous != null) {
                val verticalGap = line.y - (previous.y + previous.h)
                val indentDelta = abs(line.x - previous.x)
                val fontDelta = abs(line.fontSize - previous.fontSize)
                val sameFont = fontDelta <= max(1.6f, previous.fontSize * 0.14f)
                val paragraphGap = max(7.5f, previous.fontSize * 0.82f)
                val likelyContinuation = verticalGap <= paragraphGap &&
                    indentDelta <= max(12f, previous.fontSize * 1.8f) &&
                    sameFont &&
                    !looksLikeStandaloneStructure(line.text)

                if (likelyContinuation) {
                    previous.text = joinParagraph(previous.text, line.text)
                    val right = line.x + line.w
                    previous.w = max(previous.w, right - previous.x)
                    previous.h = max(previous.h, line.y + line.h - previous.y)
                    previous.fontSize = (previous.fontSize + line.fontSize) / 2f
                    previous.lineCount += 1
                    continue
                }
            }
            blocks.add(Block(line.text.trim(), line.x, line.y, line.w, line.h, line.fontSize))
        }
        return blocks
    }

    private fun classifyPageBlocks(blocks: List<Block>, pageNumber: Int, pageCount: Int): List<ClassifiedBlock> {
        if (blocks.isEmpty()) return emptyList()
        val medianFont = median(blocks.map { it.fontSize })
        val pageTop = blocks.minOfOrNull { it.y } ?: 0f

        val raw = blocks.mapIndexed { index, b ->
            val text = cleanSpacing(b.text.trim())
            val front = isFrontMatterBlock(text, pageNumber, b.y, pageTop)
            val type: String
            val confidence: String

            when {
                front != null -> { type = front; confidence = "HIGH" }
                looksLikePageNumber(text, b) -> { type = "PAGE_NUMBER"; confidence = "HIGH" }
                isReferenceSection(text) -> { type = "HEADING"; confidence = "HIGH" }
                isReferenceItem(text) -> { type = "REFERENCE_ITEM"; confidence = "HIGH" }
                isFigureCaption(text) -> { type = "FIGURE_CAPTION"; confidence = "HIGH" }
                isListItem(text) -> { type = "LIST_ITEM"; confidence = "HIGH" }
                isTableLike(text) -> { type = "TABLE_LIKE"; confidence = "MEDIUM" }
                isHeading(text, b.fontSize, medianFont, index, blocks) -> {
                    type = if (b.fontSize >= medianFont * 1.30f) "HEADING" else "SUBHEADING"
                    confidence = if (b.fontSize >= medianFont * 1.30f) "HIGH" else "MEDIUM"
                }
                isAuthorLine(text) && pageNumber == 1 -> { type = "AUTHOR"; confidence = "HIGH" }
                else -> { type = "BODY"; confidence = "HIGH" }
            }
            ClassifiedBlock(text, b.x, b.y, b.w, b.h, b.fontSize, type, confidence)
        }.toMutableList()

        // Promote the most plausible actual title on the first document page.
        if (pageNumber == firstContentPage(raw)) {
            val candidate = raw.indices
                .filter { raw[it].type in setOf("HEADING", "SUBHEADING", "BODY") }
                .filter { raw[it].text.length in 5..140 }
                .maxWithOrNull(
                    compareBy<Int> { raw[it].fontSize }
                        .thenByDescending { -raw[it].y }
                )
            if (candidate != null) {
                val r = raw[candidate]
                raw[candidate] = r.copy(type = "TITLE", confidence = "HIGH")
            }
        }

        return raw
    }

    private fun firstContentPage(blocks: List<ClassifiedBlock>): Int = 1

    /** Repository/front matter is deliberately phrase/position based, not keyword based. */
    private fun isFrontMatterBlock(text: String, page: Int, y: Float, pageTop: Float): String? {
        val lower = text.lowercase(Locale.US)
        val nearTop = y <= pageTop + 250f
        if (page != 1 && !lower.contains("repository citation") && !lower.contains("creative commons")) return null

        return when {
            lower == "umass chan medical school" -> "METADATA"
            lower.contains("escholarship@umasschan") -> "METADATA"
            lower.contains("cancer concepts: a guidebook for the non-oncologist") -> "METADATA"
            lower == "radiation oncology" || lower == "oncologist" -> "METADATA"
            looksLikeDate(text) -> "METADATA"
            lower.startsWith("let us know how access to this document") -> "NOTICE"
            lower.startsWith("follow this and additional works at") || isUrl(text) -> "URL"
            lower.contains("part of the cancer biology commons") -> "METADATA"
            lower.contains("pathological conditions, signs and symptoms commons") -> "METADATA"
            lower.contains("repository citation") || lower.contains("retrieved from") || lower.contains("doi.org/") -> "CITATION"
            lower == "creative commons license" || lower.contains("licensed under a creative commons") || lower.contains("creativecommons.org") -> "LICENSE"
            lower.contains("accepted for inclusion in cancer concepts") -> "LICENSE"
            nearTop && isAuthorLine(text) -> "AUTHOR"
            else -> null
        }
    }

    private fun detectRepeatedFurniture(pages: List<PageAnalysis>): Set<String> {
        if (pages.size < 2) return emptySet()
        val occurrences = HashMap<String, MutableSet<Int>>()
        pages.forEach { page ->
            page.blocks.forEach { block ->
                val nearTop = block.y <= page.pageHeight * 0.13f
                val nearBottom = block.y + block.h >= page.pageHeight * 0.88f
                if (nearTop || nearBottom) {
                    val key = normalizeForKey(block.text)
                    if (key.length in 3..100) occurrences.getOrPut(key) { mutableSetOf() }.add(page.pageNumber)
                }
            }
        }
        return occurrences.filter { (_, pageNums) ->
            pageNums.size >= max(2, min(4, pages.size / 2))
        }.keys
    }

    private fun isRepeatedFurnitureBlock(block: Block, pageHeight: Float, repeated: Set<String>): Boolean {
        val key = normalizeForKey(block.text)
        if (!repeated.contains(key)) return false
        val nearTop = block.y <= pageHeight * 0.13f
        val nearBottom = block.y + block.h >= pageHeight * 0.88f
        return nearTop || nearBottom
    }

    private fun isHeading(text: String, font: Float, medianFont: Float, index: Int, blocks: List<Block>): Boolean {
        val t = text.trim()
        if (t.isEmpty() || t.length > 180) return false
        if (isReferenceItem(t) || isListItem(t) || isFigureCaption(t)) return false
        val numbered = Regex("^(?:\\d+(?:\\.\\d+)*[.)]?|[IVX]+[.)])\\s+.+", RegexOption.IGNORE_CASE).matches(t)
        val titleCaseLike = t.firstOrNull()?.isUpperCase() == true && !t.endsWith(".")
        val large = font >= medianFont * 1.12f
        val short = t.length <= 100
        val hasSpaceAround = hasHeadingSpacing(index, blocks)
        return numbered || (large && short && (titleCaseLike || hasSpaceAround))
    }

    private fun hasHeadingSpacing(index: Int, blocks: List<Block>): Boolean {
        if (index < 0 || index >= blocks.size) return false
        val current = blocks[index]
        val previousGap = if (index > 0) current.y - (blocks[index - 1].y + blocks[index - 1].h) else 20f
        val nextGap = if (index + 1 < blocks.size) blocks[index + 1].y - (current.y + current.h) else 20f
        return previousGap >= max(9f, current.fontSize * 0.8f) || nextGap >= max(9f, current.fontSize * 0.8f)
    }

    private fun isReferenceSection(text: String): Boolean =
        Regex("^(references|bibliography|works cited)$", RegexOption.IGNORE_CASE).matches(text.trim())

    private fun isReferenceItem(text: String): Boolean {
        return Regex("^\\d+[.)]\\s+.+").matches(text.trim()) &&
            (text.contains(".") || text.contains("et al", ignoreCase = true)) &&
            text.length >= 25
    }

    private fun isListItem(text: String): Boolean {
        return Regex("^(?:\\d+[.)]|[•▪◦–—-])\\s+.+").matches(text.trim())
    }

    private fun isFigureCaption(text: String): Boolean {
        return Regex("^(figure|fig\\.?|table)\\s*\\d+[a-z]?(?:\\s*[,.:)]|\\s).+", RegexOption.IGNORE_CASE)
            .containsMatchIn(text.trim())
    }

    private fun isTableLike(text: String): Boolean {
        val tokens = text.trim().split(Regex("\\s{2,}|\\t"))
        return tokens.size in 2..5 && tokens.all { it.length in 1..70 } &&
            text.length <= 180 && !text.contains(". ")
    }

    private fun looksLikePageNumber(text: String, block: Block): Boolean {
        val t = text.trim()
        return Regex("^(?:page\\s+)?\\d{1,4}$", RegexOption.IGNORE_CASE).matches(t) && block.w < 80f
    }

    private fun isAuthorLine(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        if (lower.contains("@") || lower == "et al.") return false
        if (lower.startsWith("by ")) return true
        if (lower.contains("the university") || lower.contains("university of") || lower.contains("medical school") || lower.contains("cancer center")) {
            val before = lower.substringBefore("the university")
                .substringBefore("university of")
                .substringBefore("medical school")
                .trim()
            val tokens = before.split(Regex("\\s+")).filter { it.isNotBlank() }
            return tokens.size in 2..6
        }
        return Regex("\\b(?:md|phd|ba|ma|rn|do|et al\\.?)\\b", RegexOption.IGNORE_CASE).containsMatchIn(text) && text.length <= 140
    }

    private fun isUrl(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("https://") || lower.contains("http://") || lower.startsWith("www.")
    }

    private fun looksLikeDate(text: String): Boolean =
        Regex("^(?:\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[-/]\\d{1,2}[-/]\\d{4})$").matches(text.trim())

    private fun cleanSpacing(text: String): String =
        text.replace(Regex("\\s+"), " ").trim()

    private fun joinParagraph(a: String, b: String): String {
        val left = a.trimEnd()
        val right = b.trimStart()
        if (left.endsWith("-") && right.firstOrNull()?.isLetter() == true) {
            return left.dropLast(1) + right
        }
        return "$left $right"
    }

    private fun normalizeForKey(text: String): String =
        text.lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()

    private fun overlap(a1: Float, a2: Float, b1: Float, b2: Float): Float =
        max(0f, min(a2, b2) - max(a1, b1))

    private fun median(values: List<Float>): Float {
        if (values.isEmpty()) return 10f
        val s = values.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.1f", v)

    companion object {
        private const val REQUEST_PDF = 100
        private const val DUP_CELL = 3.0f
        private val FRONT_MATTER_TYPES = setOf("METADATA", "NOTICE", "URL", "CITATION", "LICENSE", "AUTHOR")
    }
}

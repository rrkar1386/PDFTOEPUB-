# PDF → EPUB V0.9

## Purpose
V0.9 is a reconstruction-first structural analysis release based on the V0.8 test results.
It is intended to be built as the next Android APK and tested against the same PDF that produced the V0.8 screenshots.

## Main architectural change
The pipeline is now:

`PDF glyphs → geometric cleanup → line reconstruction → column/order reconstruction → paragraph/block reconstruction → repeated furniture suppression → structural classification → document reading order`

Classification is deliberately downstream of reconstruction.

## Problems addressed together
- Character/glyph duplication caused by overlapping PDF text spans.
- Cross-column and large-gap line welding.
- Incorrect paragraph continuation.
- Repeated running headers and page furniture.
- Page-number noise.
- Repository/front-matter contamination of the document body.
- Weak heading detection.
- Broken list/reference continuity.
- Figure-caption separation.
- Simple aligned/table-like text.
- Hyphenated line continuation.

## Important limitation
This release is still a diagnostic structural-analysis prototype. It does **not** generate an EPUB yet.

The supplied environment did not contain Gradle/Android SDK, so a real Android APK build could not be executed here. The Kotlin source was syntax/type checked against local Android/PDFBox API stubs successfully. The next validation step is to build with the project's normal Android/GitHub Actions environment and run the same test PDF.

## Upgrade compatibility
`applicationId` remains `com.pdf_to_epub.v06` intentionally, so versionCode 9 can upgrade the installed V0.8 application rather than creating a separate app.

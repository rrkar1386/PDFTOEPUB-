package com.pdf_to_epub.v06

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.InputStream
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/**
 * PDF -> structural analysis prototype.
 *
 * V0.8 fixes the V0.7 observations as a group rather than one rule at a time:
 * - separates repository/front-matter from the document's real reading order
 * - checks AUTHOR before generic METADATA
 * - prevents repository title/notice/license text from becoming headings
 * - identifies the real document title from the remaining candidates
 * - analyzes every page, while keeping page boundaries
 * - preserves citation, URL, notice and license blocks as special blocks
 * - keeps a clean diagnostic view so the classifier can be verified before EPUB generation
 */
class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var selectedUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
        }

        val title = TextView(this).apply {
            text = "PDF → EPUB\nV0.8 — Structural analysis"
            textSize = 28f
        }

        val select = Button(this).apply { text = "SELECT PDF" }
        val analyze = Button(this).apply { text = "ANALYZE + CLASSIFY" }

        output = TextView(this).apply {
            textSize = 15f
            setPadding(0, 12, 0, 0)
            setTextIsSelectable(true)
        }

        root.addView(title)
        root.addView(select)
        root.addView(analyze)
        root.addView(
            ScrollView(this).apply { addView(output) },
            LinearLayout.LayoutParams(-1, 0, 1f)
        )
        setContentView(root)

        select.setOnClickListener {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "application/pdf"
                    addCategory(Intent.CATEGORY_OPENABLE)
                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    )
                }, REQUEST_PDF
            )
        }

        analyze.setOnClickListener {
            selectedUri?.let { analyzePdf(it) }
                ?: run { output.text = "Please select a PDF first." }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PDF && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            try {
                data?.data?.let {
                    contentResolver.takePersistableUriPermission(
                        it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
            } catch (_: Exception) {
                // Some document providers do not support persistable permissions.
            }
            output.text = "Selected PDF:\n${selectedUri ?: ""}\n\nPress ANALYZE + CLASSIFY."
        }
    }

    private fun analyzePdf(uri: Uri) {
        output.text = "Analyzing all pages, layout and structure…"
        Thread {
            try {
                val result = contentResolver.openInputStream(uri)?.use { analyzeDocument(it) }
                    ?: "Could not open PDF."
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread {
                    output.text = "Analysis error:\n${e.javaClass.simpleName}: ${e.message ?: "unknown error"}"
                }
            }
        }.start()
    }

    private fun analyzeDocument(input: InputStream): String {
        PDDocument.load(input).use { doc ->
            if (doc.numberOfPages == 0) return "PDF has no pages."

            val allPages = mutableListOf<PageAnalysis>()
            var rawCount = 0
            var cleanedCount = 0
            var lineCount = 0
            var blockCount = 0

            for (pageNumber in 1..doc.numberOfPages) {
                val stripper = LayoutStripper()
                stripper.startPage = pageNumber
                stripper.endPage = pageNumber
                stripper.sortByPosition = true
                stripper.getText(doc)

                val cleaned = deduplicateCharacters(stripper.items)
                val lines = buildLines(cleaned)
                val blocks = buildBlocks(lines)
                val classified = classifyBlocks(blocks)

                rawCount += stripper.items.size
                cleanedCount += cleaned.size
                lineCount += lines.size
                blockCount += blocks.size
                allPages.add(PageAnalysis(pageNumber, lines, classified))
            }

            return formatResult(
                doc.numberOfPages,
                rawCount,
                cleanedCount,
                lineCount,
                blockCount,
                allPages
            )
        }
    }

    private fun formatResult(
        pageCount: Int,
        rawCount: Int,
        cleanedCount: Int,
        lineCount: Int,
        blockCount: Int,
        pages: List<PageAnalysis>
    ): String {
        val primary = pages.flatMap { page ->
            page.blocks.filter { it.type !in SPECIAL_TYPES }
        }
        val special = pages.flatMap { page ->
            page.blocks.filter { it.type in SPECIAL_TYPES }
        }

        val sb = StringBuilder()
        sb.append("Pages: $pageCount\n")
        sb.append("Analyzed pages: $pageCount\n")
        sb.append("Raw text items: $rawCount\n")
        sb.append("After duplicate cleanup: $cleanedCount\n")
        sb.append("Detected lines: $lineCount\n")
        sb.append("Estimated blocks: $blockCount\n\n")

        sb.append("DOCUMENT READING ORDER\n")
        sb.append("----------------------\n")
        if (primary.isEmpty()) {
            sb.append("No primary document blocks detected.\n")
        } else {
            primary.forEach { b ->
                sb.append(b.text.trim()).append('\n')
            }
        }

        sb.append("\nREPOSITORY / FRONT-MATTER (KEPT SEPARATE)\n")
        sb.append("-----------------------------------------\n")
        special.forEach { b ->
            sb.append("[${b.type}] ${b.text.trim()}\n")
        }

        sb.append("\nCLASSIFIED LAYOUT BLOCKS\n")
        sb.append("------------------------\n")
        pages.forEach { page ->
            sb.append("PAGE ${page.pageNumber}\n")
            page.blocks.forEachIndexed { i, b ->
                sb.append("BLOCK ${i + 1}\n")
                sb.append("TYPE: ${b.type}\n")
                sb.append("CONFIDENCE: ${b.confidence}\n")
                sb.append("x=${fmt(b.x)}  y=${fmt(b.y)}  w=${fmt(b.w)}  h=${fmt(b.h)}\n")
                sb.append("font≈${fmt(b.fontSize)}\n")
                sb.append("text: ${b.text.trim()}\n\n")
            }
        }
        return sb.toString()
    }

    data class PageAnalysis(
        val pageNumber: Int,
        val lines: List<Line>,
        val blocks: List<ClassifiedBlock>
    )

    data class Item(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float
    )

    data class Line(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    data class Block(
        var text: String,
        var x: Float,
        var y: Float,
        var w: Float,
        var h: Float,
        var fontSize: Float
    )

    data class ClassifiedBlock(
        val text: String,
        val x: Float,
        val y: Float,
        val w: Float,
        val h: Float,
        val fontSize: Float,
        val type: String,
        val confidence: String
    )

    class LayoutStripper : PDFTextStripper() {
        val items = mutableListOf<Item>()

        override fun processTextPosition(text: TextPosition) {
            val s = text.unicode ?: return
            if (s.isNotEmpty() && s.any { !it.isWhitespace() }) {
                items.add(
                    Item(
                        text = s,
                        x = text.xDirAdj,
                        y = text.yDirAdj,
                        w = text.widthDirAdj,
                        h = text.heightDir,
                        fontSize = text.fontSizeInPt
                    )
                )
            }
        }
    }

    private fun deduplicateCharacters(items: List<Item>): List<Item> {
        if (items.isEmpty()) return emptyList()
        val result = mutableListOf<Item>()

        // Grid-keyed de-duplication avoids the O(n²) scan used by V0.7 while
        // retaining the same tolerance for PDF duplicate glyphs.
        val seen = HashSet<String>()
        for (item in items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })) {
            val key = buildString {
                append(item.text)
                append('|')
                append((item.x / 0.8f).toInt())
                append('|')
                append((item.y / 0.8f).toInt())
                append('|')
                append((item.fontSize / 1.0f).toInt())
            }
            if (seen.add(key)) result.add(item)
        }
        return result
    }

    private fun buildLines(items: List<Item>): List<Line> {
        if (items.isEmpty()) return emptyList()
        val sorted = items.sortedWith(compareBy<Item> { it.y }.thenBy { it.x })
        val lines = mutableListOf<MutableList<Item>>()

        for (item in sorted) {
            val target = lines.lastOrNull { line ->
                val avgY = line.map { it.y }.average().toFloat()
                val avgH = line.map { it.h }.average().toFloat()
                abs(item.y - avgY) <= max(2.5f, avgH * 0.55f)
            }
            if (target == null) lines.add(mutableListOf(item)) else target.add(item)
        }

        return lines.map { chars ->
            val ordered = chars.sortedBy { it.x }
            val text = StringBuilder()
            var previous: Item? = null

            for (c in ordered) {
                if (previous != null) {
                    val gap = c.x - (previous.x + previous.w)
                    val spaceThreshold = max(1.2f, minOf(c.fontSize, previous.fontSize) * 0.22f)
                    if (gap > spaceThreshold) text.append(' ')
                }
                text.append(c.text)
                previous = c
            }

            val left = ordered.minOf { it.x }
            val right = ordered.maxOf { it.x + it.w }
            val top = ordered.minOf { it.y }
            val bottom = ordered.maxOf { it.y + it.h }
            val font = ordered.map { it.fontSize }.average().toFloat()
            Line(text.toString(), left, top, right - left, bottom - top, font)
        }.sortedBy { it.y }
    }

    private fun buildBlocks(lines: List<Line>): List<Block> {
        if (lines.isEmpty()) return emptyList()
        val blocks = mutableListOf<Block>()

        for (line in lines) {
            val previous = blocks.lastOrNull()
            if (previous != null) {
                val verticalGap = line.y - (previous.y + previous.h)
                val sameColumn = abs(line.x - previous.x) <= max(18f, line.fontSize * 2.5f)
                val similarFont = abs(line.fontSize - previous.fontSize) <=
                    max(2.5f, previous.fontSize * 0.25f)

                if (verticalGap <= max(10f, line.fontSize * 0.9f) && sameColumn && similarFont) {
                    previous.text += " " + line.text
                    val right = line.x + line.w
                    previous.w = max(previous.w, right - previous.x)
                    previous.h = max(previous.h, line.y + line.h - previous.y)
                    previous.fontSize = (previous.fontSize + line.fontSize) / 2f
                    continue
                }
            }
            blocks.add(Block(line.text, line.x, line.y, line.w, line.h, line.fontSize))
        }
        return blocks
    }

    private fun classifyBlocks(blocks: List<Block>): List<ClassifiedBlock> {
        if (blocks.isEmpty()) return emptyList()

        val medianFont = blocks.map { it.fontSize }.sorted().let { values ->
            if (values.size % 2 == 1) values[values.size / 2]
            else (values[values.size / 2 - 1] + values[values.size / 2]) / 2f
        }

        val preliminary = blocks.map { b ->
            val t = b.text.trim()
            val pair = when {
                isLicense(t) -> "LICENSE" to "HIGH"
                isCitation(t) -> "CITATION" to "HIGH"
                isUrl(t) -> "URL" to "HIGH"
                isNotice(t) -> "NOTICE" to "HIGH"
                looksLikeDate(t) -> "METADATA" to "HIGH"
                isAuthorLine(t) -> "AUTHOR" to "HIGH" // MUST precede generic metadata.
                isRepositoryTitle(t) -> "METADATA" to "HIGH"
                isMetadata(t) -> "METADATA" to "HIGH"
                else -> when {
                    b.fontSize >= medianFont * 1.30f && t.length <= 180 -> "HEADING" to "HIGH"
                    b.fontSize >= medianFont * 1.12f && t.length <= 180 -> "SUBHEADING" to "MEDIUM"
                    else -> "BODY" to "LOW"
                }
            }
            pair
        }

        // Select the most plausible actual document title only from blocks that
        // are not repository/front-matter material. Prefer large font, then an
        // early page position, but do not let a repository title compete.
        val titleCandidate = blocks.indices
            .filter { preliminary[it].first in setOf("HEADING", "SUBHEADING", "BODY") }
            .filter { i ->
                val t = blocks[i].text.trim()
                t.length in 5..120 &&
                    !looksLikeDate(t) &&
                    !isRepositoryTitle(t) &&
                    !isNotice(t) &&
                    !isUrl(t) &&
                    !isCitation(t) &&
                    !isLicense(t)
            }
            .maxWithOrNull(
                compareBy<Int> { blocks[it].fontSize }
                    .thenByDescending { -blocks[it].y }
            )

        return blocks.mapIndexed { index, b ->
            val result = if (index == titleCandidate) "TITLE" to "HIGH" else preliminary[index]
            ClassifiedBlock(
                b.text.trim(), b.x, b.y, b.w, b.h, b.fontSize,
                result.first, result.second
            )
        }
    }

    private fun isRepositoryTitle(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("cancer concepts: a guidebook for the non-oncologist") ||
            (lower.contains("cancer concepts") && lower.contains("guidebook"))
    }

    private fun isUrl(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("https://") || lower.contains("http://") || lower.startsWith("www.")
    }

    private fun isCitation(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("repository citation") ||
            lower.contains("retrieved from") ||
            lower.contains("doi.org/") ||
            lower.contains("doi:")
    }

    private fun isLicense(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("creative commons license") ||
            lower.contains("licensed under a creative commons") ||
            lower.contains("creativecommons.org")
    }

    private fun isNotice(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.startsWith("let us know how access to this document") ||
            lower.startsWith("follow this and additional works at") ||
            lower.startsWith("for more information, please contact") ||
            lower.contains("accepted for inclusion in")
    }

    private fun isAuthorLine(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        if (lower.contains("@") || isRepositoryTitle(text)) return false
        if (lower == "et al." || lower.startsWith("by ")) return true

        val institutionMarker = listOf("the university", "university of", "medical school", "cancer center")
            .firstOrNull { lower.contains(it) }
        if (institutionMarker != null) {
            val beforeInstitution = lower.substringBefore(institutionMarker).trim()
            val tokens = beforeInstitution.split(Regex("\\s+")).filter { it.isNotBlank() }
            return tokens.size in 2..5 &&
                tokens.all { token -> token.replace(".", "").all { ch -> ch.isLetter() || ch == '-' } }
        }

        return Regex("\\b(et al\\.?|md|phd|ba|ma|rn|do)\\b", RegexOption.IGNORE_CASE)
            .containsMatchIn(text) && text.length <= 140
    }

    private fun isMetadata(text: String): Boolean {
        val lower = text.lowercase(Locale.US)
        return lower.contains("university") ||
            lower.contains("medical school") ||
            lower.contains("department") ||
            lower.contains("center") ||
            lower.contains("escholarship") ||
            lower.contains("@") ||
            lower.contains("commons") ||
            lower.contains("oncology") ||
            lower == "oncologist" ||
            lower.contains("repository")
    }

    private fun looksLikeDate(text: String): Boolean {
        return Regex("^(?:\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}|\\d{1,2}[-/]\\d{1,2}[-/]\\d{4})$")
            .matches(text.trim())
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.1f", v)

    companion object {
        private const val REQUEST_PDF = 100
        private val SPECIAL_TYPES = setOf("METADATA", "NOTICE", "URL", "CITATION", "LICENSE")
    }
}
